package com.dev.hare.firebasepushmodule.http.model

object HttpConstantModel {
    var token_sequence = -1
}