package com.dev.hare.firebasepushmodule.model.abstracts

abstract class AbstractNotificationBigStyleModel {
    var bigContentTitle: String? = null
    var summaryText: String? = null
}