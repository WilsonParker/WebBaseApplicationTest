package com.dev.hare.firebasepushmodule.model

import android.graphics.Bitmap
import com.dev.hare.firebasepushmodule.model.abstracts.AbstractNotificationBigStyleModel

class NotificationBigTextStyleModel : AbstractNotificationBigStyleModel() {
    var bigText: String? = null
}