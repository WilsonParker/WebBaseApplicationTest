package com.dev.hare.firebasepushmodule.http.model

data class HttpResultModel (
    var code: String?,
    var message: String?
)