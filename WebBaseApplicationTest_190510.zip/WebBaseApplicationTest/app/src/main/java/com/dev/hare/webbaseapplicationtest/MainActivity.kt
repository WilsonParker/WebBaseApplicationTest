package com.dev.hare.webbaseapplicationtest

import android.os.Bundle
import com.dev.hare.firebasepushmodule.sample.FCMUtil
import com.dev.hare.webbasetemplatemodule.activity.BaseIntroActivity
import com.dev.hare.webbasetemplatemodule.activity.BaseMainActivity

class MainActivity : BaseMainActivity() {
    override val introClass: Class<BaseIntroActivity>
        get() = IntroActivity::class.java as Class<BaseIntroActivity>

    override fun onCreateInit(savedInstanceState: Bundle?) {
        setContentView(R.layout.activity_main)
        FCMUtil.getToken()

        /*ImagePicker.with(this)
            .crop(1f, 1f)	    		//Crop Square image(Optional)
            .compress(1024)			//Final image size will be less than 1 MB(Optional)
            .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
            .start()*/
    }

}
